<?php
/**
 * @version   4.1.8 September 18, 2015
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2015 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
// no direct access
defined( 'GANTRY_VERSION' ) or die( 'Restricted index access' );

global $gantry;

/* Load the default index.php file */
include( dirname( __FILE__ ) . '/index.php' );