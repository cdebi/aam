This contains a library of common background images for use in any template.

This content would be ideal for serving via CDN delivery.