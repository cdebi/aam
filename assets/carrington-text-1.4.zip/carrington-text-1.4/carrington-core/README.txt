## carrington-core/

### Overview

This directory contains Carrington's custom features and functionality.


### Supported Override Filenames

- (none)


### File Descriptions

You do not need to do anything with files in this folder; they should remain as-is.
