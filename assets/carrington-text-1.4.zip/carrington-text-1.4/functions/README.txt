## functions/

This directory contains custom features and functionality for this particular Carrington based theme.

This directory is not used by the Carrington engine (template naming conventions are not supported), it is provided solely for convenience and for better organization of these files.